package com.example.projekpapb2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class PenerapanTeknologi extends AppCompatActivity {

    RecyclerView rvMateri;
    MateriAdapter adapter;
    ArrayList<MateriModel> daftarMateri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_materi);

        rvMateri = findViewById(R.id.rvMateri);
        rvMateri.setLayoutManager(new LinearLayoutManager(this));

        daftarMateri = new ArrayList<>();
        daftarMateri.add(new MateriModel("Penerapan Teknologi di Bidang Pendidikan"));
        daftarMateri.add(new MateriModel("Penerapan Teknologi di Bidang Kesehatan"));
        daftarMateri.add(new MateriModel("Penerapan Teknologi di Bidang Transportasi"));
        daftarMateri.add(new MateriModel("Penerapan Teknologi di Bidang Industri"));
        daftarMateri.add(new MateriModel("Penerapan Teknologi di Bidang Komunikasi"));

        adapter = new MateriAdapter(this, daftarMateri, materi -> {

            Intent intent = new Intent(PenerapanTeknologi.this, DetailPenerapanActivity.class);
            intent.putExtra("judul", materi.getJudul());
            startActivity(intent);

        });

        rvMateri.setAdapter(adapter);

        Button btnKembali = findViewById(R.id.btnKembali);
        btnKembali.setOnClickListener(v -> {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        });
    }
}
