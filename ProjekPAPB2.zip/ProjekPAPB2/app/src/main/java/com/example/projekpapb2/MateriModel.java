package com.example.projekpapb2;

public class MateriModel {
    private String judul;

    public MateriModel(String judul) {
        this.judul = judul;
    }

    public String getJudul() {
        return judul;
    }
}
