package com.example.projekpapb2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ManfaatTeknologi extends AppCompatActivity {

    RecyclerView rvMateri;
    MateriAdapter adapter;
    ArrayList<MateriModel> daftarMateri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_materi);

        rvMateri = findViewById(R.id.rvMateri);
        rvMateri.setLayoutManager(new LinearLayoutManager(this));

        daftarMateri = new ArrayList<>();
        daftarMateri.add(new MateriModel("Manfaat Teknologi Bagi Pendidikan"));
        daftarMateri.add(new MateriModel("Manfaat Teknologi Bagi Ekonomi"));
        daftarMateri.add(new MateriModel("Manfaat Teknologi Bagi Dunia Kerja"));
        daftarMateri.add(new MateriModel("Dampak Positif Teknologi"));
        daftarMateri.add(new MateriModel("Dampak Negatif Teknologi"));

        adapter = new MateriAdapter(this, daftarMateri, materi -> {

            Intent intent = new Intent(ManfaatTeknologi.this, DetailManfaatActivity.class);
            intent.putExtra("judul", materi.getJudul());
            startActivity(intent);

        });

        rvMateri.setAdapter(adapter);

        Button btnKembali = findViewById(R.id.btnKembali);
        btnKembali.setOnClickListener(v -> {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        });
    }
}
