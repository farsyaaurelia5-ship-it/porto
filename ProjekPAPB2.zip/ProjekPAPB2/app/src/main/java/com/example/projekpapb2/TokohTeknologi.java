package com.example.projekpapb2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class TokohTeknologi extends AppCompatActivity {

    RecyclerView rvMateri;
    MateriAdapter adapter;
    ArrayList<MateriModel> daftarMateri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_materi);

        // Inisialisasi RecyclerView
        rvMateri = findViewById(R.id.rvMateri);
        rvMateri.setLayoutManager(new LinearLayoutManager(this));

        // Data tokoh
        daftarMateri = new ArrayList<>();
        daftarMateri.add(new MateriModel("Nikola Tesla – Penemu listrik dan elektromagnetisme"));
        daftarMateri.add(new MateriModel("Thomas Edison – Penemu bola lampu & fonograf"));
        daftarMateri.add(new MateriModel("Tim Berners-Lee – Penemu World Wide Web"));
        daftarMateri.add(new MateriModel("Steve Jobs – Inovasi komputer & smartphone"));
        daftarMateri.add(new MateriModel("Elon Musk – Pengembangan teknologi ruang angkasa & transportasi"));

        // Adapter dengan klik listener
        adapter = new MateriAdapter(this, daftarMateri, materi -> {
            Intent intent = new Intent(TokohTeknologi.this, DetailTokohActivity.class);
            intent.putExtra("judul", materi.getJudul());
            startActivity(intent);
        });

        rvMateri.setAdapter(adapter);

        // Tombol kembali (opsional) – pastikan ada di layout
        Button btnKembali = findViewById(R.id.btnKembali);
        if (btnKembali != null) {
            btnKembali.setOnClickListener(v -> finish());
        }
    }
}
