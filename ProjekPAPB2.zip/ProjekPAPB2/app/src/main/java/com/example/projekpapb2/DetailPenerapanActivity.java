package com.example.projekpapb2;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DetailPenerapanActivity extends AppCompatActivity {

    TextView tvJudul, tvDeskripsi;
    Button btnKembali;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_penerapan);

        tvJudul = findViewById(R.id.tvJudul);
        tvDeskripsi = findViewById(R.id.tvDeskripsi);
        btnKembali = findViewById(R.id.btnKembali);

        String judul = getIntent().getStringExtra("judul");
        tvJudul.setText(judul);

        String deskripsi = "";

        switch (judul) {

            case "Penerapan Teknologi di Bidang Pendidikan":
                deskripsi = "Teknologi banyak digunakan untuk mendukung proses belajar mengajar. "
                        + "Melalui e-learning, siswa dapat mengikuti pembelajaran secara online dari mana saja. "
                        + "Video pembelajaran membantu siswa memahami materi dengan lebih mudah dan menarik. "
                        + "Kelas virtual memungkinkan guru dan siswa berinteraksi tanpa harus bertatap muka langsung. "
                        + "Selain itu, aplikasi edukasi menyediakan materi interaktif, latihan soal, dan fitur belajar mandiri.";
                break;

            case "Penerapan Teknologi di Bidang Kesehatan":
                deskripsi = "Di bidang kesehatan, teknologi membantu pemeriksaan dan pengobatan menjadi lebih cepat "
                        + "dan akurat. Telemedicine memungkinkan konsultasi jarak jauh. "
                        + "Robot bedah memberikan presisi tinggi dalam operasi. "
                        + "Smartwatch dapat memantau kondisi kesehatan secara real time. "
                        + "Rekam medis digital mempermudah penyimpanan data pasien.";
                break;

            case "Penerapan Teknologi di Bidang Transportasi":
                deskripsi = "Teknologi mempermudah mobilitas masyarakat. Mobil listrik lebih ramah lingkungan. "
                        + "GPS membantu pengemudi menentukan rute terbaik. "
                        + "Bandara menggunakan sistem otomatis untuk meningkatkan efisiensi. "
                        + "Transportasi otonom seperti mobil tanpa sopir mulai dikembangkan.";
                break;

            case "Penerapan Teknologi di Bidang Industri":
                deskripsi = "Robotik dan otomatisasi meningkatkan efisiensi industri. "
                        + "Kecerdasan buatan digunakan untuk meminimalkan kesalahan. "
                        + "Internet of Things menghubungkan mesin sehingga perawatan dapat lebih efektif.";
                break;

            case "Penerapan Teknologi di Bidang Komunikasi":
                deskripsi = "Teknologi membuat komunikasi cepat dan mudah. "
                        + "Aplikasi chatting menyediakan pesan instan. "
                        + "Video call memudahkan tatap muka jarak jauh. "
                        + "Media sosial menjadi sarana berbagi informasi. "
                        + "Teknologi 5G mempercepat akses internet.";
                break;
        }

        tvDeskripsi.setText(deskripsi);

        // Fungsi tombol kembali
        btnKembali.setOnClickListener(v -> finish());
    }
}
