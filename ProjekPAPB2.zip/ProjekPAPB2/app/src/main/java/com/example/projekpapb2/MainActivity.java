package com.example.projekpapb2;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.example.projekpapb2.databinding.ActivityMainBinding;
import com.google.android.material.snackbar.Snackbar;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private MateriAdapter materiAdapter;
    private ArrayList<MateriModel> materiList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);

        // FAB
        binding.fab.setOnClickListener(view ->
                Snackbar.make(view, "Selamat datang di EduLearn!", Snackbar.LENGTH_LONG)
                        .setAnchorView(binding.fab)
                        .show()
        );

        // Data Materi
        materiList = new ArrayList<>();
        materiList.add(new MateriModel("Tentang Teknologi"));
        materiList.add(new MateriModel("Sejarah Teknologi"));
        materiList.add(new MateriModel("Jenis-Jenis Teknologi"));
        materiList.add(new MateriModel("Penerapan Teknologi"));
        materiList.add(new MateriModel("Manfaat & Dampak Teknologi"));
        materiList.add(new MateriModel("Tokoh & Penemu Teknologi"));

        // RecyclerView
        materiAdapter = new MateriAdapter(this, materiList, materi -> {
            String judul = materi.getJudul();
            switch (judul) {
                case "Tentang Teknologi":
                    startActivity(new Intent(MainActivity.this, TentangTeknologi.class));
                    break;
                case "Sejarah Teknologi":
                    startActivity(new Intent(MainActivity.this, SejarahTeknologi.class));
                    break;
                case "Jenis-Jenis Teknologi":
                    startActivity(new Intent(MainActivity.this, JenisTeknologi.class));
                    break;
                case "Penerapan Teknologi":
                    startActivity(new Intent(MainActivity.this, PenerapanTeknologi.class));
                    break;
                case "Manfaat & Dampak Teknologi":
                    startActivity(new Intent(MainActivity.this, ManfaatTeknologi.class));
                    break;
                case "Tokoh & Penemu Teknologi":
                    startActivity(new Intent(MainActivity.this, TokohTeknologi.class));
                    break;
            }
        });

        binding.rvMateri.setLayoutManager(new LinearLayoutManager(this));
        binding.rvMateri.setAdapter(materiAdapter);
    }
}
