package com.example.projekpapb2;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DetailTokohActivity extends AppCompatActivity {

    TextView tvJudul, tvDeskripsi;
    Button btnKembali;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_tokoh);

        tvJudul = findViewById(R.id.tvJudul);
        tvDeskripsi = findViewById(R.id.tvDeskripsi);
        btnKembali = findViewById(R.id.btnKembali);

        // Ambil data dari Intent
        String judul = getIntent().getStringExtra("judul");
        tvJudul.setText(judul);

        // Deskripsi dibuat seperti style penerapan (lebih naratif & rapi)
        String deskripsi = "";

        switch (judul) {
            case "Nikola Tesla – Penemu listrik dan elektromagnetisme":
                deskripsi = "Nikola Tesla adalah ilmuwan visioner yang membawa perubahan besar dalam dunia kelistrikan. " +
                        "Ia mengembangkan sistem arus bolak-balik (AC) yang hingga kini menjadi standar distribusi listrik di seluruh dunia. " +
                        "Selain itu, Tesla juga menciptakan motor AC, transformator Tesla, serta berbagai eksperimen mengenai transmisi nirkabel. " +
                        "Pemikirannya yang jauh melampaui zamannya menjadikan Tesla sebagai salah satu tokoh paling berpengaruh dalam perkembangan teknologi modern.";
                break;

            case "Thomas Edison – Penemu bola lampu & fonograf":
                deskripsi = "Thomas Alva Edison merupakan penemu produktif dengan lebih dari 1.000 paten sepanjang hidupnya. " +
                        "Ia dikenal luas karena menyempurnakan bola lampu pijar sehingga dapat digunakan secara aman dan tahan lama oleh masyarakat. " +
                        "Edison juga menciptakan fonograf, alat pertama yang dapat merekam dan memutar suara. " +
                        "Kerja keras dan semangat eksperimennya membuatnya menjadi simbol dari inovasi tanpa henti.";
                break;

            case "Tim Berners-Lee – Penemu World Wide Web":
                deskripsi = "Tim Berners-Lee adalah ilmuwan komputer yang menemukan World Wide Web, sistem yang memungkinkan orang " +
                        "mengakses halaman web dan terhubung melalui hyperlink. Penemuannya membuka jalan bagi internet modern, " +
                        "sehingga informasi dapat dibagikan dan diakses oleh siapa saja di seluruh dunia. " +
                        "Dampaknya sangat besar, menjadikan Berners-Lee sebagai tokoh kunci dalam era digital.";
                break;

            case "Steve Jobs – Inovasi komputer & smartphone":
                deskripsi = "Steve Jobs dikenal sebagai sosok visioner yang membawa perubahan revolusioner dalam dunia teknologi. " +
                        "Melalui Apple, ia menghadirkan perangkat seperti iPhone, iPad, dan Mac yang menekankan kesederhanaan desain namun sangat fungsional. " +
                        "Jobs selalu mendorong terciptanya teknologi yang tidak hanya canggih, tetapi juga mudah digunakan dan estetis, " +
                        "sehingga menjadi standar baru dalam industri teknologi global.";
                break;

            case "Elon Musk – Pengembangan teknologi ruang angkasa & transportasi":
                deskripsi = "Elon Musk adalah pengusaha dan inovator yang berfokus pada kemajuan teknologi masa depan. " +
                        "Ia mendirikan SpaceX untuk membuat roket yang dapat digunakan kembali dan memajukan eksplorasi luar angkasa. " +
                        "Melalui Tesla, ia juga berkontribusi besar pada perkembangan mobil listrik dan energi ramah lingkungan. " +
                        "Berbagai proyek visionernya, seperti Hyperloop dan Neuralink, menunjukkan ambisinya membangun masa depan yang lebih efisien dan berkelanjutan.";
                break;
        }

        tvDeskripsi.setText(deskripsi);

        // Tombol kembali
        btnKembali.setOnClickListener(v -> finish());
    }
}
