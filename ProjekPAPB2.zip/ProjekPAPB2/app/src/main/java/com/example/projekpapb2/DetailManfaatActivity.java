package com.example.projekpapb2;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DetailManfaatActivity extends AppCompatActivity {

    TextView tvJudul, tvDeskripsi;
    Button btnKembali;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_manfaat);

        // Inisialisasi view
        tvJudul = findViewById(R.id.tvJudul);
        tvDeskripsi = findViewById(R.id.tvDeskripsi);
        btnKembali = findViewById(R.id.btnKembali);

        // Ambil judul dari Intent
        String judul = getIntent().getStringExtra("judul");
        tvJudul.setText(judul);

        // Deskripsi berdasarkan judul
        String deskripsi = "";

        switch (judul) {

            case "Manfaat Teknologi Bagi Pendidikan":
                deskripsi =
                        "Teknologi memberikan banyak manfaat dalam dunia pendidikan. " +
                                "Proses pembelajaran menjadi lebih fleksibel melalui platform e-learning yang memungkinkan siswa belajar dari mana saja. " +
                                "Materi dalam bentuk video, animasi, dan simulasi membuat pembelajaran lebih menarik dan mudah dipahami. " +
                                "Guru juga dapat memberikan tugas, nilai, dan materi secara digital sehingga proses administrasi lebih cepat. " +
                                "Selain itu, teknologi mendukung kolaborasi antar siswa melalui aplikasi diskusi dan proyek online.";
                break;

            case "Manfaat Teknologi Bagi Ekonomi":
                deskripsi =
                        "Teknologi memberikan dampak besar terhadap pertumbuhan ekonomi. " +
                                "Perusahaan dapat meningkatkan produktivitas melalui otomatisasi dan sistem komputerisasi. " +
                                "Bisnis online seperti e-commerce memudahkan transaksi jual beli tanpa batas jarak. " +
                                "Sistem perbankan digital mempercepat transaksi keuangan, pembayaran, dan investasi. " +
                                "Selain itu, teknologi membuka peluang kerja baru di bidang IT, digital marketing, hingga analisis data.";
                break;

            case "Manfaat Teknologi Bagi Dunia Kerja":
                deskripsi =
                        "Kemajuan teknologi mengubah cara bekerja menjadi lebih cepat dan efisien. " +
                                "Aplikasi manajemen proyek membantu tim bekerja secara terorganisir meskipun berbeda lokasi. " +
                                "Perangkat otomatis mendukung pekerjaan berat sehingga hasil lebih akurat. " +
                                "Teknologi komunikasi seperti video conference memudahkan rapat jarak jauh. " +
                                "Selain itu, dunia kerja kini membutuhkan keterampilan digital sehingga peluang karier semakin luas.";
                break;

            case "Dampak Positif Teknologi":
                deskripsi =
                        "Teknologi memberikan banyak dampak positif dalam kehidupan sehari-hari. " +
                                "Komunikasi menjadi lebih cepat dan mudah melalui internet, chat, serta video call. " +
                                "Akses informasi terbuka luas sehingga siapa pun bisa belajar hal baru kapan saja. " +
                                "Di bidang kesehatan, teknologi membantu diagnosa dan pengobatan lebih akurat. " +
                                "Selain itu, teknologi mempermudah pekerjaan, transportasi, dan hiburan dengan berbagai aplikasi modern.";
                break;

            case "Dampak Negatif Teknologi":
                deskripsi =
                        "Walaupun bermanfaat, teknologi juga memiliki dampak negatif. " +
                                "Penggunaan berlebihan dapat menyebabkan kecanduan gadget dan menurunnya interaksi sosial. " +
                                "Penyebaran informasi palsu (hoax) semakin mudah melalui media sosial. " +
                                "Data pribadi rentan dicuri jika keamanan digital tidak dijaga. " +
                                "Selain itu, perkembangan teknologi dapat menyebabkan berkurangnya lapangan kerja tertentu akibat otomatisasi.";
                break;

            default:
                deskripsi = "Deskripsi belum tersedia.";
                break;
        }


        // Tampilkan deskripsi
        tvDeskripsi.setText(deskripsi);

        // Tombol kembali
        btnKembali.setOnClickListener(v -> finish());
    }
}
