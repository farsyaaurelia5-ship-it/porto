package com.example.projekpapb2;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

public class EduLearnWidget extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            // Intent untuk membuka MainActivity saat widget diklik
            Intent intent = new Intent(context, MainActivity.class);
            PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_IMMUTABLE);

            // Tampilan layout widget
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.edulearn_widget);
            views.setOnClickPendingIntent(R.id.widget_container, pendingIntent);

            // Update widget
            appWidgetManager.updateAppWidget(appWidgetId, views);
        }
    }
}
