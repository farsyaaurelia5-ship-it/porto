package com.example.projekpapb2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MateriAdapter extends RecyclerView.Adapter<MateriAdapter.ViewHolder> {

    private Context context;
    private ArrayList<MateriModel> daftarMateri;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(MateriModel materi);
    }

    public MateriAdapter(Context context, ArrayList<MateriModel> daftarMateri, OnItemClickListener listener) {
        this.context = context;
        this.daftarMateri = daftarMateri;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        // 🔥 PENTING! Pakai layout buatan kamu
        View view = LayoutInflater.from(context).inflate(R.layout.item_materi, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MateriModel materi = daftarMateri.get(position);

        holder.tvJudul.setText(materi.getJudul());

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onItemClick(materi);
        });
    }

    @Override
    public int getItemCount() {
        return daftarMateri.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        TextView tvJudul;

        ViewHolder(@NonNull View itemView) {
            super(itemView);

            // 🔥 Sesuaikan dengan ID di XML kamu
            tvJudul = itemView.findViewById(R.id.tvJudulMateri);
        }
    }
}
